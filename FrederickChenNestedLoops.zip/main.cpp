#include <bits/stdc++.h>
#include <string>
using namespace std;

int main() {
  
  //Question 1
  
  //creating infinite loop so that this code will keep on executing until user wants it to end
  while (true){

    //creating variables, and making a random number and so that it will be random through every time the code is run through
    int guessLottery;
    string playAgain;
    srand(time(0));
    int LotteryNumber = rand() % 899+100;

    //asking user for their guess of what the number will be
    cout << "Play by entering a 3-digit number: "; cin >> guessLottery;
    cout << "Your guess was: " << guessLottery << endl;
    cout << "The lottery number was: " << LotteryNumber << endl;

    //determining individual digits of the two numbers
    int guessHunDig = guessLottery / 100;
    int guessTenDig = (guessLottery - guessHunDig * 100) / 10;
    int guessOneDig = (guessLottery - guessHunDig * 100 ) % 10;
    int lotteryHunDig = LotteryNumber / 100;
    int lotteryTenDig = (LotteryNumber - lotteryHunDig * 100) / 10;
    int lotteryOneDig = (LotteryNumber - lotteryHunDig * 100 ) % 10;


  //determining which prize the user will get through their guess

  //if number is perfect match, uer will win 1 million dollars
  if (guessLottery == LotteryNumber)
    cout << "You won: $1000000";
  
  //if all digits match up with each other in no particular order, the user will win 1k dollars
  else if ((guessHunDig == lotteryHunDig || guessHunDig == lotteryTenDig || guessHunDig == lotteryOneDig) && (guessTenDig == lotteryHunDig || guessTenDig == lotteryTenDig || guessTenDig == lotteryOneDig) && (guessOneDig == lotteryHunDig || guessOneDig == lotteryTenDig || guessOneDig == lotteryOneDig))
    cout << "You won: $1000";

  //if 2 of the 3 digits match up with each other in no particular order, the user will win 100 dollars
  else if (((guessHunDig == lotteryHunDig || guessHunDig == lotteryTenDig || guessHunDig == lotteryOneDig) && (guessTenDig == lotteryHunDig || guessTenDig == lotteryTenDig || guessTenDig == lotteryOneDig)) || ((guessHunDig == lotteryHunDig || guessHunDig == lotteryTenDig || guessHunDig == lotteryOneDig) && (guessOneDig == lotteryHunDig || guessOneDig == lotteryTenDig || guessOneDig == lotteryOneDig)) || ((guessTenDig == lotteryHunDig || guessTenDig == lotteryTenDig || guessTenDig == lotteryOneDig) && (guessOneDig == lotteryHunDig || guessOneDig == lotteryTenDig || guessOneDig == lotteryOneDig)))
    cout << "You won: $100";

  //if one of the 3 digits match up with each other in no particular order, the user will win 10 dollars
  else if (guessHunDig == lotteryHunDig || guessHunDig == lotteryTenDig || guessHunDig == lotteryOneDig || guessTenDig == lotteryHunDig || guessTenDig == lotteryTenDig || guessTenDig == lotteryOneDig || guessOneDig == lotteryHunDig || guessOneDig == lotteryTenDig || guessOneDig == lotteryOneDig)
    cout << "You won: $10";
  
  //if none of the digits match with each other, the user will not win any money
  else
    cout << "You won: $0";
  
  cout << endl;
  
  //asking if the user wants to play again ,and will leave this infinite loop if they say no
  cout << "Would you like to play again? (y/n) ";
  cin >> playAgain;
  cout << endl;
    if (playAgain == "n"){
      cout << "Thank you for playing." << endl;
      break;
    }
  }

  cout << endl;
  


  //Question 2
  
  //creating infinite loop so that this code will keep on executing until user wants it to end
  while(true){

    //asking user for the phrase they want to convert, and creating variable
    cout << "Enter a phrase: ";
    string phrase = ""; 
    int spaces = 0;

    //forever while loop for spaced input
    while(true){

        //gets the user's input for the phrase
        string substring; 
        cin >> substring;

        //adding substring and space to phrase
        phrase = phrase + substring + " ";
        spaces++;

        //if enter is entered, it will break this infite loop
        if(getchar() ==  '\n'){
            break;
        }
    }

    //creating a string and character variables
    string num; 
    char replay;

    //loop so phone number has 7 digits
    for(int i = 0 ; i < (7 + spaces - 1) ; i++){
      //if phrase character is uppercase, this converts it to lowercase so all inputted characters are loewrcase
      if(isupper(phrase[i])) phrase[i] = tolower(phrase[i]);
      //if character entered is space, add hyphen
      if(phrase[i] == ' '){
        if(i == (phrase.length()-1))
          continue;
        else
          num += '-';
      }

      //if character is a,b,c, add 2
      if(phrase[i]=='a'||phrase[i]=='b'||phrase[i]=='c') num += '2';
      //if character is d,e,f, add 3
      if(phrase[i]=='d'||phrase[i]=='e'||phrase[i]=='f') num += '3';
      //if character is g,h,i, add 4
      if(phrase[i]=='g'||phrase[i]=='h'||phrase[i]=='i') num += '4';
      //if character is j,k,l, add 5
      if(phrase[i]=='j'||phrase[i]=='k'||phrase[i]=='l') num += '5';
      //if character is m,n,o, add 6
      if(phrase[i]=='m'||phrase[i]=='n'||phrase[i]=='o') num += '6';
      //if character is p,q,r,s, add 7
      if(phrase[i]=='p'||phrase[i]=='q'||phrase[i]=='r'||phrase[i]=='s') num += '7';
      //if character is t,u,v, add 8
      if(phrase[i]=='t'||phrase[i]=='u'||phrase[i]=='v') num += '8';
      //if character is w,x,y,z, add 9
      if(phrase[i]=='w'||phrase[i]=='x'||phrase[i]=='y'||phrase[i]=='z') num += '9';

    }

    //outputting the phone number
    cout << "The phone number is: " << num << '\n';
    
    //asking if the user wants to convert a phrase again, and will leave this infinite loop if they say no
    cout << "Would you like to process another phrase (y/n)?: ";
    cin >> replay;
    if(replay == 'n'){
        cout << "Thank you for using the app.";
        break;
    }
  }
}