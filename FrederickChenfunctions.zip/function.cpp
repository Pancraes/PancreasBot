#include <bits/stdc++.h>
//calling header file we made
#include "function.h" 
using namespace std;
//functions file

//displays menu
int menu(int choice)
{

  cout << endl << endl << "Enter the function number to test: ";

  //asks user for input
  cin >> choice;
  
  //switch statement for all allowed inputs from the user, and then calls the function dealing with that question
  switch(choice)
  {
    case(1): Question1(); break;
    case(2): reverseNum(); break;
    case(3): isPalindrome(); break;
    case(4): displaySortedNumbers(); break;
    case(5): futureInvestmentValue(); break;
    case(6): distance();
  }

  //if user wants to quit, and breaks main loop if choice is -1
  if(choice == -1) cout << "Thank you for using the functions module.";
  
  //returns choice number
  return choice;
  cout << endl;
}

//creates all of the pentagonal numbers
int getPentagonalNumber(int n)
{
  
  //calculates pentagonal numbers
  int p = n*(3*n-1)/2;
  return p;
}

//defining question1 function
void Question1()
{

  //prints first 50 pentagonal numbers
  for(int i= 1;i<=50;i++)
  {
    int p = getPentagonalNumber(i);
    if(i % 5 ==0)
      cout <<setw(8)<<p<<endl;
    else 
      cout << setw(8)<<p;
  }
}

//defining reversing integer function
int reverse(int n)
{

  //result and remaining variable declaration
  int revNum = 0; int remainder = 0;

  //while original number does not equal 0
  while(n != 0)
  {

    //take last digit of original number
    remainder = n % 10;

    //adding last digit 
    revNum = revNum * 10 + remainder;
    n = n / 10;
  }

  return revNum;
}

//defining reverseNum function
void reverseNum()
{

  //asking user to enter the number they want to reverse
  cout << "Enter a number to reverse: ";
  int num; 
  cin >> num;

  //displaying the reversed number by calling reverse function
  cout << "The number after reversal is " << reverse(num);
}

//defining isPalindrome function
void isPalindrome()
{
  int n; 
  
  //asking user to enter an integer they want to reverse
  cout << "Enter an integer: "; 
  cin >> n;

  //determining if the number is a palindrome or not
  int p = reverse(n);
  if (n == p)
    cout << "Integer is a palindrome";
  else 
    cout << "Integer is not a palindrome";
  
}


//defining displaySortedNumbers function
void displaySortedNumbers()
{
  double num1, num2, num3;

  //asking user to enter three numbers
  cout << "Enter your first number: ";
  cin >> num1;
  cout << "Enter your second number: ";
  cin >> num2;
  cout << "Enter your third number: ";
  cin >> num3;

  //determining what order the numbers will be in in order of smallest to largest
  double nums[3];
  if (num1 < num2 && num1 < num3){
    nums[0] = num1;
    if (num2 < num3)
    {
      nums[1]=num2;
      nums[2]=num3;
    }
    else
    {
      nums[1]=num3;
      nums[2]=num2;
    }
  }
  else if (num2 < num1 && num2 < num3){
    nums[0] = num2;
    if (num1 < num3)
    {
      nums[1]=num1;
      nums[2]=num3;
    }
    else
    {
      nums[1]=num3;
      nums[2]=num1;
    }
  }

  else{
    nums[0] = num3;
    if (num2 < num1)
    {
      nums[1]=num2;
      nums[2]=num1;
    }
    else
    {
      nums[1]=num1;
      nums[2]=num2;
    }
  }
  cout << "The sorted numbers are: " << nums[0] << ", " << nums[1] << ", "<< nums[2];
}

//defining futureInvestmentValue
void futureInvestmentValue(){

  //creating variables and assigning values to them through user input
  double investmentAmount, annualInvestmentRate;
  cout << "The Amount Invested: "; 
  cin >> investmentAmount;
  cout << "Annual Interest Rate: "; 
  cin >> annualInvestmentRate;

  //creating headers
  cout << "Years" << setw(15) << "Future Value" << endl;

  //cycling through for loop 30 times
  for(int years=1;years<=30;years++){
    cout << years;

    //making sure lists are aligned
    if (years>=10) 
      cout << setw(14);
    else
      cout << setw(15);
    
    //displaying future balue
    cout << investmentAmount*pow((1+(annualInvestmentRate*0.01)),years) << endl;
  }

}

//defining getDistance function
double getDistance(int x1, int y1, int x2, int y2){

  //distance formula, and displaying results
  double distance = sqrt(pow((x2-x1),2) + pow((y2-y1),2));
  cout << distance << endl;
  return distance;
}

//defining distance function
void distance(){

  //creating the necessary points to calculate distance
  int x1,y1,x2,y2;

  //asking user to input values for the coordinates
  cout << "Enter coordinates x1: "; 
  cin >> x1;
  cout << "Enter coordinates x2: "; 
  cin >> x2;
  cout << "Enter coordinates y1: "; 
  cin >> y1;
  cout << "Enter coordinates y2: "; 
  cin >> y2;

  //displaying distance through calling getDistance function
  double distance = getDistance(x1,y1,x2,y2);
  cout << "The distance between (" << setprecision(2) << x1 << "," << y1 << ") and (" << x2 << "," << y2 << ")" << " is " << distance;
}
