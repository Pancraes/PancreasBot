#include <bits/stdc++.h>
#include "function.h"
using namespace std;
//main file
int main(){
  //displaying menu
  cout << "***************************************************************" << endl;
  cout << "*** 		Welcome to User-Defined Functions Assignment 	***"<< endl;
  cout << "***************************************************************"<< endl<< endl;

  //displays menu choices
  cout << "Please choose an option(1-6 or -1 to Quit)"<< endl<< endl;
  cout << "1. Pentagonal numbers"<< endl;
  cout << "2. Reverse a number"<< endl;
  cout << "3. Palindrome application"<< endl;
  cout << "4. Display sorted number"<< endl;
  cout << "5. Future Investment"<< endl;
  cout << "6. Calculate distance"<< endl;
  cout << "7. Enter -1 to Quit";

  //forever while loop
  while(true){
    
    //declare choice variable
    int choice;

    //menu function call
    int res = menu(choice);
    
    //menu function returns choice
    //if user enters -1 as choice; break loop
    if(res == -1) break;
  }
}