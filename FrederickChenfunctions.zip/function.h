//header file

//question 1
int getPentagonalNumber(int n);
void Question1();

//question 2 but split into two parts
int reverse(int n);
void reverseNum();

bool palindrome(int n);
void isPalindrome();

//question 3
void displaySortedNumbers();

//question 4
void futureInvestmentValue();

//question 5
double getDistance();
void distance();

//menu
int menu(int n);