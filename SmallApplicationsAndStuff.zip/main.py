"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 6 U5 - Question 1
Purpose: I will display a 5x10 number grid showing the first 50 pentagonal numbers
"""

def getPentagonalNumber(n):
  return n*(3*n-1)//2

def question1():
  for n in range(1, 51):
    p = getPentagonalNumber(n)
    if n % 5 == 0:
      print(f"{p:5d}")
    else:
      print(f"{p:5d}", end = "")
  print()

"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 6 U5 - Question 2
Purpose: I will get the individual digits from an integer and display of all the digits
"""

def sumDigits(n):
  total = 0
  for digit in n:
    total += int(digit)
  return total

def question2():
  n = input("Please enter an integer to find its digit sum: ")
  total = sumDigits(n)
  print(f"The digit sum of {n} is {total}")
  print()
"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 6 U5 - Question 3
Purpose: I will reverse the order of the the integer entered by the user
"""
def reverse(number):
  s = ""
  for i in range(len(number)-1, -1, -1):
    s+=number[i]
  return s

def question3():
  number = str(input("Please enter your integer: "))
  print(reverse(number))
  print()
"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 6 U5 - Question 4
Purpose: i will see if the integer entered by the user is a palindrome or not
"""
def isPalindrome(number):
  palindrome = reverse(number)
  if number == palindrome:
    print("The number you've entered is a palindrome")
  else:
    print("The number you've entered is not a palindrome")

def question4():
    number = str(input("Please enter your number: "))
    isPalindrome(number)
    print()
"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 6 U5 - Question 5
Purpose: I will calculate the sum of the coins that the user has
"""
def getDollarAmount(quarters, dimes, nickels, pennies):
  sum = quarters*0.25+dimes*0.10+nickels*0.05+pennies*0.01
  print(f"Total: ${sum:.2f}")

def addCoins():
  print("Enter your total coins: ")
  quarters = int(input("Quarters: "))
  dimes = int(input("Dimes: "))
  nickels = int(input("Nickels: "))
  pennies = int(input("Pennies: "))
  print()
  getDollarAmount(quarters, dimes, nickels, pennies)
  print()

"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 6 U5 - Question 6
Purpose: I display a menu and for the user to choose any of the 6 different options and then execute that option and repeat until the user tells me to stop
"""
def menu():
  print("********************************************************")
  print()
  print("      Welcome to User-Defined Functions Assignment")
  print()
  print("********************************************************")
  print()
  print("Please choose an option(1-6 or -1 to quit)")
  print()
  print("1. Pentagonal Numbers")
  print("2. Digit Sum")
  print("3. Reverse the Number")
  print("4. Is Number a Palindrome")
  print("5. Sum of Coins")
  print("6. Menu")
  print()

menu()
while True:
  choice = input("Please make your selection from the menu above: ")
  if choice == "1":
    question1()
  elif choice == "2":
    question2()
  elif choice == "3":
    question3()
  elif choice == "4":
    question4()
  elif choice == "5":
    addCoins()
  elif choice == "6":
    print()
    menu()
  elif choice == "-1":
    break
  else:
    print("Please enter a valid choice.")
    print()
print("Thank you for using the app.")