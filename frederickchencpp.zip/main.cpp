#include <bits/stdc++.h>
#include "function.h"
using namespace std;

int main(){
  while(true){
    //shows the choices
    char choice;
    cout << "Please choose an option" << endl << endl;
    cout << "a. Assign Grades" << endl;
    cout << "b. Random Numbers" << endl;
    cout << "c. Reverse list using function" << endl;
    cout << "d. Anagrams" << endl;
    cout << "e. Employee Salary" << endl;
    cout << "f. Quit" << endl << endl;
    cout << "Enter the function letter to test: ";

    //gets the user's choice
    cin >> choice;

    //switch statement for different choice cases and calls menu option functions
    switch(choice){
      case('a'): assignGrades(); break;
      case('b'): randNum(); break;
      case('c'): reverseList(); break;
      case('d'): anagram(); break;
      case('e'): employeeSalary(); break;
    }
    
    //if user decides to quit
    if(choice == 'f'){
      cout << "Thank you for using the functions module.";
      //return choice number; break main file loop if choice is f
      return choice;
    }
  }
}