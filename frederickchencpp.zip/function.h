//header file

void assignGrades();

void randNum();

void reverseList();

void anagram();

void employeeSalary();