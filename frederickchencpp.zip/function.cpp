#include <bits/stdc++.h>
#include "function.h"
#include <string>
using namespace std;

//Grades function
void assignGrades(){

  //opening the grades text file
  ofstream grades;
  grades.open("Grades.txt");

  //opening students text file
  ofstream student;
  student.open("Students.txt");

  //making marks
  int studentNumber, mark1, mark2, mark3, mark4, markSum;
  double average;
  string firstName, lastName;

  //getting grades for the students
  cout << endl << "How many students: ";
  cin >> studentNumber;
  
  for(int i = 0; i < studentNumber; i++){
    cout << endl << "What is the first and last name of the student: ";
    cin >> firstName >> lastName;
    cout << "Enter grade 1: ";
    cin >> mark1;
    cout << "Enter grade 2: ";
    cin >> mark2;
    cout << "Enter grade 3: ";
    cin >> mark3;
    cout << "Enter grade 4: ";
    cin >> mark4;

    //getting the average mark
    markSum =  (mark1 + mark2 + mark3 + mark4);

    double average = markSum/4.0;
    
    char grade;
    
    //assigning grades
    if(average >= 90){
      grade = 'A';
    }
    else if(average < 90 && average >= 60){
      grade = 'B';
    }
    else if(average < 60 && average >=50){
      grade = 'C';
    }
    else{
      grade = 'F';
    }

    //displaying grade
    if(grade == 'A' or grade == 'F'){
      cout << "The average mark for " << firstName << " " << lastName << " is " << average << "% which is an " << grade << endl;

    grades << "The average mark for " << firstName << " " << lastName << " is " << average << "% which is an " << grade << endl;

    }

    else{
      cout << "The average mark for " << firstName << " " << lastName << " is " << average << "% which is a " << grade << endl;

    grades << "The average mark for " << firstName << " " << lastName << " is " << average << "% which is a " << grade << endl;
    }

    //putting the name and grades into Students.txt
    student << firstName << " " << lastName << ", " << mark1 << ", " << mark2 << ", " << mark2 << ", " << mark3 << ", " << mark4 << endl;
  }
  cout << endl;
}

//Random Number Counter function
void randNum(){

  //making sure numbers generated are random
  srand(time(NULL));
  
  int a[10] = {0};

  //getting how many times each number shows up
  for (int count = 1 ; count <= 1000 ; count++){
    int randInt = rand() % 10;
    a[randInt] += 1;
  }

  cout << endl;

  //displaying how much of each number was displayed
  for(int i = 0 ; i < 10 ; i++){
    cout << i << " showed up " << a[i] << " times" << endl;
  }
  cout << endl;
}

//Reverse list of numbers Function
void reverseList(){
  int size;

  //getting list size and numbers in the list
  cout << endl << "Enter list size: ";
  cin >> size;
  cout << "Enter your list of numbers: ";

  //putting these numbers into an array
  int arr[size];
  for(int i = 0 ; i < size ; i++ ){
    int n;
    cin >> n;
    arr[i] = n;
  }

  //displaying and getting the reverse of the list
  cout << endl << "The reverse of your number list is: ";
  int i = 0; 
  int j = size-1;
  while(i < j){
    int srt = arr[i];
    arr[i] = arr[j];
    arr[j] = srt;
    i++;
    j--;
  }

  for(int i = 0 ; i < size ; i++){
    cout << arr[i] << " ";
  }

  cout << endl;
  cout << endl;
}

// Anagram checking function
void anagram(){
  int letters1[26] = {0};
  int letters2[26] = {0};

  //getting two words from user
  string s1, s2;
  cout << endl << "Enter two words: ";
  cin >> s1 >> s2;

  //checking to see if both words are anagrams of each other or no
  for(auto x : s1){
    if(isupper(x)) x = tolower(x);
    int position = x - 'a';
    letters1[position]++;
  }

  for(auto x : s2){
    if(isupper(x)) x = tolower(x);
    int position = x - 'a';
    letters2[position]++;
  }

  //displaying if the two words are anagrams or no
  for(int i=0;i<26;i++){
    if(letters1[i] != letters2[i]){
      cout << "The two entered strings are not anagrams.";
      return;
    }
  }

  cout << "The two entered strings are anagrams.";
  cout << endl;
  cout << endl;
}

//employee calculating function
void employeeSalary(){

  //opening Employees.txt and putting the following inputs into Employees.txt
  ofstream stringOut;
  ifstream stringIn;
  stringOut.open("Employees.txt");

  //asking user for information about 5 employees and doing this 5 times
  for(int i = 0 ; i < 5 ; i++){
    string firstName, lastName; int total; int rate;
    cout << "Enter employee first name and last name: "; cin >> firstName >> lastName;
    stringOut << firstName << " " << lastName;

    for(int j = 1 ; j < 6 ; j++){
      int hours;
      cout << "Hours worked for day " << j << ": ";
      cin >> hours;
      stringOut << " " << hours;
    }

    cout << "Hourly rate: ";
    cin >> rate;
    cout << endl;
    stringOut << " " << rate << endl;
  }
  
  //opening salary and employees.txt
  stringOut.close();
  stringOut.open("Salary.txt");
  stringIn.open("Employees.txt");
  

  //displaying information about the employee that the user inputted
  //displaying name
  while(stringIn) {

    string firstName;
    stringIn >> firstName;

    if (firstName.compare("") != 0) {
      string name, lastName;
      stringIn >> lastName;
      name = firstName + " " + lastName;
      cout << "Employee Name: " << name << endl;
      stringOut << "Employee Name: " << name << endl;

      int totalHours = 0;
      int hours;
      for(int i = 0 ; i < 5 ; i++) {
        stringIn >> hours;
        totalHours += hours;
      }

      //displaying total hours that the employee has worked
      cout << "Total Hours: " << totalHours << "$" << endl;
      stringOut << "Total Hours: " << totalHours << "$" << endl;

      int rate = 0;
      stringIn >> rate;

      int salary = 0;

      if(totalHours > 30){
        salary = 30 * rate;
      }
      else{
        salary = totalHours * rate;
      }

      //displaying the amount that they made from the regular non overtime salary
      cout << "Regular Salary: " << salary << "$" << endl;
      stringOut << "Regular Salary: " << salary << "$" << endl;

      int overtime = 0;
      if(totalHours > 30){
        overtime = totalHours - 30;
      }

      //displaying the money made from their overtime work
      cout << "Overtime: " << overtime << endl;
      stringOut << "Overtime: " << overtime << endl;
      
      //calculating the amount made from overtime
      overtime = overtime * rate * 1.5;
      int totalAmount = overtime + salary;
      
      //displaying the total amount made by the employee
      cout << "Total Amount: " << totalAmount << "$" << endl << endl;
      stringOut << "Total Amount: " << totalAmount << "$" << endl;
    }
  }
  stringOut.close();
  stringIn.close();
  cout << endl;
}