#include <bits/stdc++.h>
using namespace std;

int main(){

  double papaSalary, mamaHouse, mamaCar, jacksonHour, jacksonWeek, jacksonWork;

  //asking user for inputs for value of variables
  cout << "What is the yearly salary of Papa Jackson? ";
  cin >> papaSalary;
  cout << "How much house insurance did Mama Jackson sell? ";
  cin >> mamaHouse;
  cout << "How much car insurance did Mama Jackson sell? ";
  cin >> mamaCar;
  cout << "Enter Junior's hourly rate: ";
  cin >> jacksonHour;
  cout << "Enter Junior's number of hours per week: ";
  cin >> jacksonWeek;
  cout << "Enter number of weeks Junior worked: ";
  cin >> jacksonWork;
  cout << fixed << setprecision(2) << endl;


  //displaying income header
  cout << setw(30) << setfill('-') << " INCOME " << setw(22) << "-" << setfill(' ') << endl;

  //calculating and setting value for income of mama and jackson, as well sa the total income
  const double incomeMama = (mamaHouse*.125)+(mamaCar*.098);
  const double incomeJackson = (jacksonHour * jacksonWeek * jacksonWork);
  const float totalIncome = incomeMama + incomeJackson + papaSalary;
  
  //displaying income
  cout << "Papa Jackson Income:" << setw(4) << "$" << papaSalary << endl;
  cout << "Mama Jackson Income:" << setw(4) << "$" << incomeMama  << endl;
  cout << "Junior Jackson Income: $" << incomeJackson  << endl;
  cout << "Total family Income:" << setw(4) << "$" << totalIncome << endl;
  cout << "Average family Income: $" << totalIncome / 3 << endl << endl;


  // displaying income tax header
  cout << setw(30) << setfill('-') << " Income TAX " << setw(22) << "-" << setfill(' ') << endl;

  //calculating and setting value for taxes and netTotal
  const double taxPapa = papaSalary * 0.2;
  const double taxMama = incomeMama * 0.15;
  const double taxJackson  = incomeJackson * 0.05;
  const float taxTotal = taxPapa + taxMama + taxJackson;
  const double netTotal = totalIncome - taxTotal;

  //displaying taxes paid by family members and overall tax rate and net income and monthly net income
  cout << "Tax paid by Papa Jackson:" << setw(16) << "$" << taxPapa << endl;
  cout << "Tax paid by Mama Jackson:" << setw(16) << "$" << taxMama << endl;
  cout << "Tax paid by Junior Jackson:" << setw(14) << "$" << taxJackson << endl;
  cout << "Total amount of Tax paid by the family: $" << taxTotal << endl;
  cout << fixed << setprecision(14);
  cout << "Overall tax rate as a percentage is:" << setw(21)  << taxTotal / totalIncome * 100 << "%" << endl;
  cout << fixed << setprecision(2);
  cout << "Total net income :" << setw(23) << "$" << netTotal << endl;
  cout << "Average monthly net income:" << setw(14) << "$" << netTotal / 12 << endl << endl;


//header for investment
  cout << setw(30) << setfill('-') << " INVESTMENT " << setw(22) << "-" << setfill(' ') << endl;
  
  //calculating value for investment and creating variables
  double whole, numerator, denominator;
  const double investment = netTotal*0.08;

  //asking for user input for values needed for this part of the assignment
  cout << "Please enter the price for one share of stock..." << endl;
  cout << "Please enter the whole number portion: ";
  cin >> whole;
  cout << "Please enter the numerator of the fraction portion: ";
  cin >> numerator;
  cout << "Please enter the denominator of the fraction portion: ";
  cin >> denominator;
  cout << "Amount of investment: $" << investment << endl;
//calculating share
  const double share = whole + (numerator/denominator);
//displaying shares of stock invested
  cout << "Numbers of shares of stock invested: " << int(investment/share) << endl << endl;


//displaying header for electrical expenses
  cout << setw(35) << setfill('-') << " Expenses ELECTRICITY " << setw(17) << "-" << setfill(' ') << endl;

  int electricity, discount;
//saking for user input for electricity variable values
  cout << "How many units of electricity over the year? ";
  cin >> electricity;
  cout << "After how many months did the discount finish? ";
  cin >> discount;
//calculating and inputting values into other variables
  const double billMonth = (electricity / 12) * 0.1;
  const double subTotal = ((electricity - (billMonth * discount)) * 0.16);
  const double elecTotal = (subTotal - 50) * 1.02;
//displaying total cost of electrcity bill
  cout << "Total cost of electricity bill for the year: $" << elecTotal << endl << endl;


//displaying header for phone bill expenses
  cout << setw(35) << setfill('-') << " Expenses PHONE BILL " << setw(17) << "-" << setfill(' ') << endl;
  
  double minYearly, minTime, timeCost;
  //asking user for variable values for the cost and time
  cout << "Number of minutes spent over the year: ";
  cin >> minYearly;
  cout << "Number of minutes in a block of time: ";
  cin >> minTime;
  cout << "Cost for each block of time: ";
  cin >> timeCost;
  //calculating billtotal value
  int periodNum = minYearly / minTime;
  const double billTotal = periodNum * timeCost;
//displaying cost of phone bill
  cout << "Cost of the phone bill: $" << billTotal << endl << endl;


//displaying header for expense of gas
  cout << setw(35) << setfill('-') << " Expenses GAS COST " << setw(17) << "-" << setfill(' ') << endl;

  double distanceYearly, efficiency, gasPrice;
//asking user for input for values in this part of the assignment
  string carBrand, type;
  cout << "Brand and type of the vehicle: ";
  cin >> carBrand >> type;
  cout << "Distance travelled over the year: ";
  cin >> distanceYearly;
  cout << "Fuel Efficiency (km/l): ";
  cin >> efficiency;
  cout << "Average gas price ($/L): ";
  cin >> gasPrice;
  //calculating gstotal price
  const double gasTotal = distanceYearly / efficiency * gasPrice;
//displaying total cost of the gasoline
  cout << "Total cost of gasoline for the year: $" << gasTotal << endl << endl;
  

  //displaying header of mortgage
  cout << setw(35) << setfill('-') << " Expenses MORTGAGE " << setw(17) << "-" << setfill(' ') << endl;

  double mortgage;
//asking user for value for mortgage payment
  cout << "Amount of bi-weekly mortgage payment: ";
  cin >> mortgage;

  //calculating mortgage total
  const double mortgageTotal = mortgage * 26;

//displaying total mortgage payment
  cout << "Total mortgage payment for the year: $" << mortgageTotal << endl << endl;


//displaying header for other expenses
  cout << setw(30) << setfill('-') << " OTHER EXPENSES " << setw(22) << "-" << setfill(' ') << endl;

//calculating value for other variables
  const double remainder = netTotal - (investment + elecTotal + billTotal + gasTotal + mortgageTotal);
  const  double groceries = remainder * 0.6;
  const double entertainment = remainder * 0.25;
  const double cashSavings = remainder * 0.15;
 
//displaying costs of other expenses 
  cout << "Amount used on groceries:" << setw(6) << "$" << groceries << endl;
  cout << "Amount used on entertainment: $" << entertainment << endl;
  cout << "Amount of cash savings:" << setw(8) << "$" << cashSavings << endl << endl;


//displaying header for summary
  cout << setw(30) << setfill('-') << " SUMMARY " << setw(22) << "-" << setfill(' ') << endl;

//displaying summary of costs and income
  cout << "Total household gross income: $" << totalIncome << endl;
  cout << "Total income tax paid:" << setw(9) << "$" << taxTotal << endl;
  cout << "Total expenses:" << setw(16) << "$" << gasTotal + mortgageTotal + groceries + entertainment + elecTotal + billTotal << endl;
  cout << "Total reserve:" << setw(17) << "$" << investment + cashSavings << endl;
}