#include <bits/stdc++.h>
#include "function.h"
using namespace std;

int main(){
  while(true){
    char choice;
    cout << "Please choose an option\n\n";
    cout << "a. Assign Grades\n";
    cout << "b. Random Numbers\n";
    cout << "c. Reverse list using function\n";
    cout << "d. Anagrams\n";
    cout << "e. Employee Salary\n";
    cout << "f. Quit\n\n";
    cout << "Enter the function letter to test: ";

    //choice input
    cin >> choice;

    //switch statement for different choice cases; calls menu option functions
    switch(choice){
      case('a'): assignGrades(); break;
      case('b'): randNum(); break;
      case('c'): revList(); break;
      case('d'): anagram(); break;
      case('e'): employeeSalary(); break;
    }
    
    //if user decides to quit
    if(choice == 'f'){
      cout << "Thank you for using the functions module.";
      //return choice number; break main file loop if choice is -1
      return choice;
    }
  }
}