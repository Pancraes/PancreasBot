#include <bits/stdc++.h>
#include "function.h"
#include <string>
using namespace std;

// Grades

void assignGrades(){
  // Create File Grades.txt
  ofstream outputFile;
  outputFile.open("Grades.txt");

  // Create File Student.txt
  ofstream myFile;
  myFile.open("Students.txt");

  // Create Variable
  int numStu, m1, m2, m3, m4, totMark;
  double average;
  string fName, lName;

  // Enter student info
  cout << "\nHow many students: "; cin >> numStu;
  
  // For loop - loop 5 times for each student, asks for grades, calculate average, and output results
  for(int i = 0; i < numStu; i++){
    cout << "\nWhat is the first and last name of the student: "; cin >> fName >> lName;
    cout << "Enter grade 1: "; cin >> m1;
    cout << "Enter grade 2: "; cin >> m2;
    cout << "Enter grade 3: "; cin >> m3;
    cout << "Enter grade 4: "; cin >> m4;

    totMark =  (m1 + m2 + m3 + m4);

    double average = totMark/4.0;
    
    char ltrGrade;

    if(average >= 90){
      ltrGrade = 'A';
    }
    else if(average < 90 && average >= 60){
      ltrGrade = 'B';
    }
    else if(average < 60 && average >=50){
      ltrGrade = 'C';
    }
    else{
      ltrGrade = 'F';
    }

    if(ltrGrade == 'A' or ltrGrade == 'F'){
      cout << "The average mark for " << fName << " " << lName << " is " << average << "% which is an " << ltrGrade << endl;

    outputFile << "The average mark for " << fName << " " << lName << " is " << average << "% which is an " << ltrGrade << endl;

    myFile << fName << " " << lName << ", " << m1 << ", " << m2 << ", " << m2 << ", " << m3 << ", " << m4 << "." << endl;
    }
    else{
      cout << "The average mark for " << fName << " " << lName << " is " << average << "% which is a " << ltrGrade << endl;

    outputFile << "The average mark for " << fName << " " << lName << " is " << average << "% which is a " << ltrGrade << endl;

    myFile << fName << " " << lName << ", " << m1 << ", " << m2 << ", " << m2 << ", " << m3 << ", " << m4 << "." << endl;

    }
  }
  cout << endl;
}

// Random Number Occurance

void randNum(){
  srand(time(NULL));
  
  // array with 10 values, all 0's
  int a[10] = {0};

  // Create 1000 random integers and add them to the list according to their ones digit
  for (int count=1;count<=1000;count++){
    int randInt = rand() % 10;
    a[randInt] += 1;
  }

  cout << endl;

  // Output the number of times the numbers 1 - 10 occur
  for(int i=0;i<10;i++){
    cout << "The number of times the number " << i << " occured was " << a[i] << " times." << endl;
  }
  cout << endl;
}

// Reverse List Function

void revList(){
  int size;
  cout << "\nEnter list size: "; cin >> size;
  cout << "Enter your list of numbers: ";
  int arr[size];
  for(int i=0;i<size;i++){
    int n; cin >> n;
    arr[i] = n;
  }

  cout << "\nThe reverse of your number list is: ";
  int i=0; int j = size-1;
  while(i < j){
    int srt = arr[i];
    arr[i] = arr[j];
    arr[j] = srt;
    i++;
    j--;
  }
  for(int i=0;i<size;i++){
    cout << arr[i] << " ";
  }
  cout << endl;
  cout << endl;
}

// Anagram Checker

void anagram(){
  int nMap[26] = {0};
  int mMap[26] = {0};

  // Collecting variables
  string s1, s2;
  cout << "\nEnter Two Words (ie. silent listen): ";
  cin >> s1 >> s2;

  // find position as add to array
  for(auto x : s1){
    if(isupper(x)) x = tolower(x);
    int pos = x - 'a';
    nMap[pos]++;
  }

  // find position and add to array
  for(auto x : s2){
    if(isupper(x)) x = tolower(x);
    int pos = x - 'a';
    mMap[pos]++;
  }

  // compare nMap and mMap. If they are equal, the 2 strings are anagrams
  for(int i=0;i<26;i++){
    if(nMap[i] != mMap[i]){
      cout << "The two entered strings are not anagrams.";
      return;
    }
  }
  cout << "The two entered strings are anagrams.";
  cout << endl;
  cout << endl;
}

// Salary Prompt

void employeeSalary(){

  // Create files
  ofstream fout;
  ifstream fin;
  fout.open("Employees.txt");

  // Enter First name, Last name, Number hours worked, Hourly rate, for 5 people
  for(int i=0;i<5;i++){
    string fname, lname; int total; int rate;
    cout << "Enter employee first name and last name: "; cin >> fname >> lname;
    fout << fname << " " << lname;
    for(int j=1;j<6;j++){
      int hours;
      cout << "Hours worked for day " << j << ": ";
      cin >> hours;
      fout << " " << hours;
    }
    cout << "Hourly rate: ";
    cin >> rate;
    cout << endl;
    fout << " " << rate << "\n";
  }
  
  fout.close();
  fout.open("Salary.txt");
  fin.open("Employees.txt");
  
  // Calculate salary, total hours worked, overtime, and total amount earned
  while(fin) {
    string fname;
    fin >> fname;
    if (fname.compare("") != 0) {
      string name, lname;
      fin >> lname;
      name = fname + " " + lname;
      cout << "Employee Name: " << name << "\n";
      fout << "Employee Name: " << name << "\n";

      int totalHours = 0;
      int hours;
      for(int i=0;i<5;i++) {
        fin >> hours;
        totalHours += hours;
      }
      cout << "\tTotal Hours: " << totalHours << "\n";
      fout << "\tTotal Hours: " << totalHours << "\n";

      int rate = 0;
      fin >> rate;

      int salary = 0;
      if(totalHours > 30){
        salary = 30 * rate;
      }
      else{
        salary = totalHours * rate;
      }
      cout << "\tRegular Salary: " << salary << "\n";
      fout << "\tRegular Salary: " << salary << "\n";

      int overtime = 0;
      if(totalHours > 30){
        overtime = totalHours - 30;
        overtime = overtime * rate * 1.5;
      }
      cout << "\tOvertime Salary: " << overtime << "\n";
      fout << "\tOvertime Salary: " << overtime << "\n";

      int totalAmount = overtime + salary;

      cout << "\tTotal Amount: " << totalAmount << "\n\n";
      fout << "\tTotal Amount: " << totalAmount << "\n";
    }
  }
  fout.close();
  fin.close();
  cout << endl;
}