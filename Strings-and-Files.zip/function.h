void assignGrades();

void randNum();

void revList();

void anagram();

void employeeSalary();