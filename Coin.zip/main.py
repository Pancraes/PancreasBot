import random
"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 4 U3 - Question 1
Purpose: The program is to generate a 3 digit number, and compare that to the 3 digit number that the user entered. The number of digits that are similar to the random number is then converted into some type of prize, and the program will display the amount won.
"""
choice = "y"
while choice != "n":
    guess = input("Please enter your 3 digit number: ")
    print("Your guess was: ", guess)
    lotteryNumber = str(random.randint(100, 999))
    print("The lottery number was: ", lotteryNumber)
    if guess == lotteryNumber:
        print("Congratulations! You've won 1000000 dollars!")
    elif (guess[0] == lotteryNumber[0] or guess[0] == lotteryNumber[1] or guess[0] == lotteryNumber[2]) and (guess[1] == lotteryNumber[0] or guess[1] == lotteryNumber[1] or guess[1] == lotteryNumber[2]) and (guess[2] == lotteryNumber[0] or guess[2] == lotteryNumber[1] or guess[2] == lotteryNumber[2]):
                print("You've won 1000 dollars!")
    elif (guess[0] == lotteryNumber[0] or guess[0] == lotteryNumber[1] or guess[0] == lotteryNumber[2]) and (guess[1] == lotteryNumber[0] or guess[1] == lotteryNumber[1] or guess[1] == lotteryNumber[2]):
            print("You've won 100 dollars")
    elif (guess[0] == lotteryNumber[0] or guess[0] == lotteryNumber[1] or guess[0] == lotteryNumber[2]) and (guess[2] == lotteryNumber[0] or guess[2] == lotteryNumber[1] or guess[2] == lotteryNumber[2]):
            print("You've won 100 dollars")
    elif (guess[1] == lotteryNumber[0] or guess[1] == lotteryNumber[1] or guess[1] == lotteryNumber[2]) and (guess[2] == lotteryNumber[0] or guess[2] == lotteryNumber[1] or guess[2] == lotteryNumber[2]):
            print("You've won 100 dollars")
    elif guess[0] == lotteryNumber[0] or guess[0] == lotteryNumber[1] or guess[0] == lotteryNumber[2]:
        print("You've won 10 dollars.")
    elif guess[1] == lotteryNumber[0] or guess[1] == lotteryNumber[1] or guess[1] == lotteryNumber[2]:
        print("You've won 10 dollars.")
    elif guess[2] == lotteryNumber[0] or guess[2] == lotteryNumber[1] or guess[2] == lotteryNumber[2]:
        print("You've won 10 dollars.")
    else:
        print("You didn't win anything")
    print()
    choice = input("Would you like to play again? (y/n): ")
    print()
print("Thank you for playing!")
print()
"""
Author: Frederick Chen
Class: ICS2O1-02
Topic: Assign # 4 U3 - Question 2
Purpose: This program will print either heads or tails, and when there are 3 either heads or tails in a row, it displays the amount of flips needed for there to be 3 same slips in a row. I will do this 10 times, and then display the average number of flips needed until it stops.
"""
total = 0
for i in range(10):
    flipRecord = ""
    totalFlips = 0
    while True:
        flip = random.randint(1, 2)
        if flip == 1:
            print("H", end=" ")
            flipRecord += "H"
            totalFlips += 1
        elif flip == 2:
            print("T", end=" ")
            flipRecord += "T"
            totalFlips += 1
        if len(flipRecord) >= 3:
            if flipRecord[-3:] == "TTT" or flipRecord[-3:] == "HHH": # [-3:] was used because [x-2] created an index out of range error, and [-3] worked
                break
    print(f"({totalFlips} flips)")
    total += totalFlips

averageFlips = total / 10
print(f"On average, {averageFlips} flips were needed.")
