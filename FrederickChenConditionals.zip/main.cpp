#include <bits/stdc++.h>
using namespace std;

int main() {
  
  //Question 1

  double speed;
  
  //asking user to enter speed of vehicle
  cout << "Enter the speed of your vehicle: "; 
  cin>> speed;
  
  //determining what category the speed entered falls under
  if (speed<20)
    cout << ("Too Slow") << endl;

  else if (speed>80)
    cout << ("Too Fast") << endl;

  else
    cout << ("Just Right") << endl;

  cout << endl;


  //Question 2

  int dayFromToday, daySum, dayOfTheWeek, dayResult;

  //asking user to enter date and future day
  cout << "Please enter today's date(0-6): "; 
  cin >> dayOfTheWeek;;
  cout << "Please enter the number of days elapsed since today: "; 
  cin >> dayFromToday;;

  //determining what day of the week it is from what the user inputted and displaying it
  switch(dayOfTheWeek)
  {
    case 0:
      cout << "Today is Sunday and the future is ";
      daySum = dayFromToday;
      break;
    case 1:
      cout << "Today is Monday and the future is ";
      daySum = dayFromToday + 1;
      break;
    case 2:
      cout << "Today is Tuesday and the future is ";
      daySum = dayFromToday + 2;
      break;
    case 3:
      cout << "Today is Wednesday and the future is ";
      daySum = dayFromToday + 3;
      break;
    case 4:
      cout << "Today is Thursday and the future is ";
      daySum = dayFromToday + 4;
      break;
    case 5:
      cout << "Today is Friday and the future is ";
      daySum = dayFromToday + 5;
      break;
    case 6:
      cout << "Today is Saturday and the future is ";
      daySum = dayFromToday + 6;
      break;
  }

  //calculating what the future day is
  dayResult = daySum % 7;

  //determining what the future day is and displaying it
  switch(dayResult)
  {
    case 0:
      cout << "Sunday"<< endl;
      break;
    case 1:
      cout << "Monday"<< endl;
      break;
    case 2:
      cout << "Tuesday"<< endl;
      break;
    case 3:
      cout << "Wednesday"<< endl;
      break;
    case 4:
      cout << "Thursday" << endl;
      break;
    case 5:
      cout << "Friday"<< endl;
      break;
    case 6:
      cout << "Saturday"<< endl;
      break;
  }

  cout << endl;


  //Question 3

  double weight, feet, inches, bmi, kg, height, heightFeet, meters;

  //asking user for information about their body
  cout << "Enter weight in pounds: "; 
  cin >> weight;
  cout << "Enter feet: "; 
  cin >> feet;
  cout << "Enter inches: "; 
  cin >> inches;

  //determining metric values from imperial inputs
  kg = weight* 0.453592;
  height = inches* 0.0254;
  heightFeet = feet * 0.3048;
  meters = height + heightFeet; 
  bmi = kg/pow(meters,2);

  // Displays BMI
  cout << "BMI is " << setprecision(2) << bmi << endl;

  if (bmi < 18.5)//BMI categories states the numbers as the following seen in the if else statement
    cout << "Underweight"<< endl;
  
  else if (bmi < 24.9)
    cout << "Normal" << endl;
  
  else if (bmi < 29.9)
    cout << "Overweight" << endl;
  
  else
    cout << "Obese" << endl;
  cout << endl;


  //Question 4

  double side1, side2, side3;

  //asking user for lengths of the sides of the triangle
  cout << "Please enter the length of your first triangle's side: "; 
  cin >> side1;
  cout << "Please enter the length of your second triangle's side: "; 
  cin >> side2;
  cout << "Please enter the length of your third triangle's side: "; 
  cin >> side3;
  
  //determining and dislaying what type of triangle it is
  if(side1==side2 && side1==side3 && side2==side3)
    cout << "Equilateral Triangle" << endl;

  else if (side1!=side2 && side1!=side3 && side2!=side3)
    cout << "Scalene Triangle" << endl;
    
  else
    cout << "Isoceles Triangle" << endl;
  
  
  cout << endl;

  
  //Question 5

  int hours, dayNum, remainingHours;

  //saking user for what day it is and how many hours have passed in the day
  cout <<  "Enter day number (1 - Sunday, 7 - Saturday): "; 
  cin >> dayNum;
  cout <<  "Enter number of hours passed: "; 
  cin >> hours;

//calculating remaining hours
  remainingHours = 24 - hours;

  //determining what day it is and displaying that as well as the remaining hours
  switch(dayNum)
  {
    case 1:
      cout << "Today is Sunday and Remainding Hours: " << remainingHours;
      break;
    case 2:
      cout << "Today is Monday and Remainding Hours: " << remainingHours;
      break;
    case 3:
      cout << "Today is Tuesday and Remainding Hours: " << remainingHours;
      break;
    case 4:
      cout << "Today is Wednesday and Remainding Hours: " << remainingHours;
      break;
    case 5:
      cout << "Today is Thursday and Remainding Hours: " << remainingHours;
      break;
    case 6:
      cout << "Today is Friday and Remainding Hours: " << remainingHours;
      break;
    case 7 :
      cout << "Today is Saturday and Remainding Hours: " << remainingHours;
      break;
  }

  cout << endl << endl;


  //q6

  int predictNumber, tensDigit, onesDigit, tensDigitRand, onesDigitRand;

  //creating the random number and asking what the user thinks it is
  int randNumber = rand() % 90+10;
  cout << "Please predict the random two digit number: "; cin >> predictNumber;

//creating values for the individual digits of the numbers
  tensDigit = predictNumber / 10;
  onesDigit = predictNumber % 10;
  tensDigitRand = randNumber / 10;
  onesDigitRand = randNumber % 10;

//determining the user's accuracy
  if (predictNumber == randNumber)
    cout << "Accuracy: 100% - The number was: "<< randNumber << endl;

  else if (onesDigit == onesDigitRand or onesDigit == tensDigitRand or tensDigit == onesDigitRand or tensDigit == tensDigitRand)//many "or"s because assignment asks for if a single digit fits with any of the other two digits
    cout << "Accuracy: 50% - The number was: "<< randNumber << endl;

  else
    cout << "Accuracy: 0% - The number was: "<< randNumber << endl;

  cout << endl;

  
  //q7

  int xCirc, yCirc, distFromOrigin;
//asking user for the value of x and y for the point
  cout << "Please enter the x value of your point: "; cin >> xCirc;
  cout << "Please enter the y value of your point: "; cin >> yCirc;
  
  //since the equation to get the distance from 2 points is sqrt((x2-x1)^2+(y2-y1)^2), we can substite on of them with both 0s, because the origin has the coordinates of 0,0. This would be sqrt((x2-0)^2+(y2-0)^2), which would be simplified to sqrt((x2)^2+(y2)^2). 

  //calculating distance of point from origin
  distFromOrigin = sqrt(pow(xCirc, 2)+pow(yCirc, 2));

  //determining and displaying if point is inside or outside of circle
  if (distFromOrigin >=-9 && distFromOrigin <= 9)
    cout << "Point (" << xCirc << ", " << yCirc << ") is in the circle." << endl;

  else
    cout << "Point (" << xCirc << ", " << yCirc << ") is not in the circle." << endl;

  cout << endl;


  //q8

  int x, y;

  //saking user for value of x and y for the point
  cout << "Please enter the x value of your point: "; cin >> x;
  cout << "Please enter the y value of your point: "; cin >> y;

  //determining and displaying if the point is in or outside of the rectangle
  if (1 >= -5 && x <= 5 && y >= -2.5 && y <= 2.5)
    cout << "Point ("<< x <<", " << y << ") is in the rectangle";

  else
    cout << "Point ("<< x <<", " << y << ") is not in the rectangle";

}